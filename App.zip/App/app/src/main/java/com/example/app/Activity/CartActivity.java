package com.example.app.Activity;

// Ορίζει το πακέτο της κλάσης ως com.example.app.Activity

import android.annotation.SuppressLint; // Εισάγει την κλάση SuppressLint από την βιβλιοθήκη android.annotation. Χρησιμοποιείται για την καταστολή προειδοποιήσεων lint στο Android Studio.
import android.content.Intent; // Εισάγει την κλάση Intent από την βιβλιοθήκη android.content. Χρησιμοποιείται για την εκκίνηση νέων δραστηριοτήτων (Activities).
import android.os.Bundle; // Εισάγει την κλάση Bundle από την βιβλιοθήκη android.os. Χρησιμοποιείται για τη μεταφορά δεδομένων μεταξύ των δραστηριοτήτων.
import android.text.Editable; // Εισάγει την κλάση Editable από την βιβλιοθήκη android.text. Παρέχει μια διεπαφή για επεξεργάσιμα κείμενα.
import android.text.InputFilter; // Εισάγει την κλάση InputFilter από την βιβλιοθήκη android.text. Χρησιμοποιείται για τον περιορισμό των χαρακτήρων που μπορούν να εισαχθούν σε ένα EditText.
import android.text.TextWatcher; // Εισάγει την κλάση TextWatcher από την βιβλιοθήκη android.text. Παρέχει μια διεπαφή για την παρακολούθηση αλλαγών στο κείμενο ενός EditText.
import android.view.View; // Εισάγει την κλάση View από την βιβλιοθήκη android.view. Αντιπροσωπεύει την βασική μονάδα διεπαφής χρήστη στην οποία βασίζονται όλα τα γραφικά στοιχεία.
import android.widget.EditText; // Εισάγει την κλάση EditText από την βιβλιοθήκη android.widget. Αντιπροσωπεύει ένα πεδίο εισαγωγής κειμένου που μπορεί να επεξεργαστεί ο χρήστης.
import android.widget.LinearLayout; // Εισάγει την κλάση LinearLayout από την βιβλιοθήκη android.widget. Χρησιμοποιείται για τη διάταξη των στοιχείων σε μια γραμμική διάταξη, είτε κατακόρυφα είτε οριζόντια.
import android.widget.RadioGroup; // Εισάγει την κλάση RadioGroup από την βιβλιοθήκη android.widget. Χρησιμοποιείται για τη διαχείριση ενός συνόλου RadioButton όπου μόνο ένα μπορεί να επιλεγεί τη φορά.
import android.widget.ScrollView; // Εισάγει την κλάση ScrollView από την βιβλιοθήκη android.widget. Χρησιμοποιείται για να επιτρέπει την κύλιση του περιεχομένου που είναι μεγαλύτερο από την προβολή.
import android.widget.TextView; // Εισάγει την κλάση TextView από την βιβλιοθήκη android.widget. Αντιπροσωπεύει ένα στοιχείο διεπαφής χρήστη που εμφανίζει κείμενο.
import android.widget.Toast; // Εισάγει την κλάση Toast από την βιβλιοθήκη android.widget. Χρησιμοποιείται για την εμφάνιση μικρών ειδοποιήσεων στην οθόνη του χρήστη.

// Εισάγει τις απαραίτητες κλάσεις από την Android βιβλιοθήκη

import androidx.appcompat.app.AppCompatActivity; // Εισάγει την κλάση AppCompatActivity από την βιβλιοθήκη androidx.appcompat.app. Παρέχει τη συμβατότητα προς τα πίσω για τις λειτουργίες δραστηριότητας (Activity) και την υποστήριξη για τη χρήση της ActionBar.
import androidx.constraintlayout.widget.ConstraintLayout; // Εισάγει την κλάση ConstraintLayout από την βιβλιοθήκη androidx.constraintlayout.widget. Χρησιμοποιείται για την δημιουργία πολύπλοκων διατάξεων με ευελιξία τοποθέτησης των στοιχείων.
import androidx.recyclerview.widget.LinearLayoutManager; // Εισάγει την κλάση LinearLayoutManager από την βιβλιοθήκη androidx.recyclerview.widget. Χρησιμοποιείται για την διαχείριση της διάταξης των στοιχείων σε ένα RecyclerView.
import androidx.recyclerview.widget.RecyclerView; // Εισάγει την κλάση RecyclerView από την βιβλιοθήκη androidx.recyclerview.widget. Παρέχει έναν πιο αποδοτικό και ευέλικτο τρόπο για την εμφάνιση μεγάλων συνόλων δεδομένων.


// Εισάγει τις απαραίτητες κλάσεις από τις βιβλιοθήκες androidx και recyclerview

import com.example.app.Adapter.CartListAdapter; // Εισάγει την κλάση CartListAdapter από το πακέτο com.example.app.Adapter. Χρησιμοποιείται για την διαχείριση της εμφάνισης των στοιχείων του καλαθιού σε ένα RecyclerView.
import com.example.app.Helper.ManagementCart; // Εισάγει την κλάση ManagementCart από το πακέτο com.example.app.Helper. Παρέχει λειτουργίες για τη διαχείριση του καλαθιού αγορών.
import com.example.app.Interface.ChangeNumberItemsListener; // Εισάγει την κλάση ChangeNumberItemsListener από το πακέτο com.example.app.Interface. Παρέχει μια διεπαφή για την παρακολούθηση αλλαγών στον αριθμό των αντικειμένων στο καλάθι.
import com.example.app.R; // Εισάγει το πακέτο R από το com.example.app. Χρησιμοποιείται για την πρόσβαση σε πόρους (resources) όπως layout, strings, drawable, κ.λπ.

// Εισάγει τις κλάσεις που έχουν δημιουργηθεί στο project

public class CartActivity extends AppCompatActivity { // Ορίζει την κλάση CartActivity που επεκτείνει την AppCompatActivity. Αυτή η κλάση αντιπροσωπεύει τη δραστηριότητα του καλαθιού αγορών.
    private RecyclerView.Adapter adapter; // Δηλώνει έναν adapter για το RecyclerView που θα χρησιμοποιηθεί για την εμφάνιση των στοιχείων του καλαθιού.
    private RecyclerView recyclerViewList; // Δηλώνει ένα RecyclerView για την εμφάνιση της λίστας των στοιχείων του καλαθιού.
    private ManagementCart managementCart; // Δηλώνει ένα αντικείμενο ManagementCart για τη διαχείριση του καλαθιού αγορών.
    private TextView totalFeeTxt, taxTxt, deliverytxt, totalTxt, emptyTxt; // Δηλώνει TextView για την εμφάνιση του συνολικού κόστους, του φόρου, των εξόδων παράδοσης, του συνολικού ποσού και ενός μηνύματος κενής λίστας.
    private double tax; // Δηλώνει μια μεταβλητή για την αποθήκευση του ποσού του φόρου.
    private EditText cardNumberEditText, cvvEditText, expiryDateEditText; // Δηλώνει EditText για την εισαγωγή του αριθμού κάρτας, του κωδικού CCV και της ημερομηνίας λήξης της κάρτας.
    private ScrollView scrollView; // Δηλώνει ένα ScrollView για να επιτρέπει την κύλιση του περιεχομένου της δραστηριότητας.

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Καθορίζει την onCreate μέθοδο που καλείται κατά τη δημιουργία της δραστηριότητας.
        super.onCreate(savedInstanceState); // Καλεί τη μέθοδο onCreate της υπερκλάσης για να εκτελέσει τις αρχικές ρυθμίσεις της δραστηριότητας.
        setContentView(R.layout.activity_cart); // Ορίζει το περιεχόμενο της δραστηριότητας χρησιμοποιώντας το layout activity_cart.

        managementCart = new ManagementCart(this); // Αρχικοποιεί το αντικείμενο managementCart με την τρέχουσα δραστηριότητα.

        initView(); // Καλεί τη μέθοδο initView για την αρχικοποίηση των στοιχείων της διεπαφής.
        initList(); // Καλεί τη μέθοδο initList για την αρχικοποίηση της λίστας των αντικειμένων του καλαθιού.
        bottomNavigation(); // Καλεί τη μέθοδο bottomNavigation για την αρχικοποίηση των κουμπιών πλοήγησης στο κάτω μέρος.
        calculateCard(); // Καλεί τη μέθοδο calculateCard για τον υπολογισμό του συνολικού κόστους, του φόρου και των εξόδων παράδοσης.

        // Βρίσκει το EditText για τον αριθμό της κάρτας
        cardNumberEditText = findViewById(R.id.cardNumberEditText); // Βρίσκει το EditText για τον αριθμό της κάρτας από το layout.

        // Θέτει φίλτρα εισόδου για να επιτρέπονται μόνο αριθμοί και περιορίζει το μήκος στους 16 χαρακτήρες
        cardNumberEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)}); // Θέτει φίλτρα εισόδου για το EditText ώστε να επιτρέπει μόνο αριθμούς και να περιορίζει το μήκος στους 16 χαρακτήρες.

        // Προσθέτει TextWatcher για να κρύβει τον αριθμό της κάρτας και να δείχνει ****
        cardNumberEditText.addTextChangedListener(new TextWatcher() { // Προσθέτει έναν TextWatcher για να κρύβει τον αριθμό της κάρτας και να δείχνει ****.
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) { // Εκτελείται μετά την αλλαγή του κειμένου στο EditText.
                String text = s.toString(); // Λαμβάνει το τρέχον κείμενο του EditText.
                if (text.length() > 0) { // Ελέγχει αν το κείμενο δεν είναι κενό.
                    StringBuilder maskedText = new StringBuilder(); // Δημιουργεί ένα νέο StringBuilder για το κείμενο με ****.
                    for (int i = 0; i < text.length(); i++) { // Επαναλαμβάνει για κάθε χαρακτήρα του κειμένου.
                        maskedText.append("*"); // Προσθέτει * για κάθε χαρακτήρα του αρχικού κειμένου.
                    }
                    cardNumberEditText.removeTextChangedListener(this); // Αφαιρεί τον TextWatcher για να αποφύγει έναν άπειρο βρόχο.
                    cardNumberEditText.setText(maskedText); // Ορίζει το EditText με το κείμενο με ****.
                    cardNumberEditText.setSelection(maskedText.length()); // Θέτει τη θέση του κέρσορα στο τέλος του κειμένου.
                    cardNumberEditText.addTextChangedListener(this); // Προσθέτει τον TextWatcher πίσω.
                }
            }
        });

        // Βρίσκει το EditText για το CCV
        cvvEditText = findViewById(R.id.cvvEditText); // Βρίσκει το EditText για το CCV από το layout.

        // Θέτει τον τύπο εισόδου σε αριθμό και το μέγιστο μήκος στους 3 χαρακτήρες για το CCV EditText
        cvvEditText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); // Θέτει τον τύπο εισόδου σε αριθμό για το CCV EditText.
        cvvEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)}); // Θέτει φίλτρα εισόδου για το CCV EditText ώστε να επιτρέπει μόνο αριθμούς και να περιορίζει το μήκος στους 3 χαρακτήρες.

        // Προσθέτει TextWatcher για να κρύβει το CCV και να δείχνει ***
        cvvEditText.addTextChangedListener(new TextWatcher() { // Προσθέτει έναν TextWatcher για να κρύβει το CCV και να δείχνει ***.
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Δεν απαιτείται
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Δεν απαιτείται
            }

            @Override
            public void afterTextChanged(Editable s) { // Εκτελείται μετά την αλλαγή του κειμένου στο EditText.
                String text = s.toString(); // Λαμβάνει το τρέχον κείμενο του EditText.
                if (text.length() > 0) { // Ελέγχει αν το κείμενο δεν είναι κενό.
                    StringBuilder maskedText = new StringBuilder(); // Δημιουργεί ένα νέο StringBuilder για το κείμενο με ***.
                    for (int i = 0; i < text.length(); i++) { // Επαναλαμβάνει για κάθε χαρακτήρα του κειμένου.
                        maskedText.append("*"); // Προσθέτει * για κάθε χαρακτήρα του αρχικού κειμένου.
                    }
                    cvvEditText.removeTextChangedListener(this); // Αφαιρεί τον TextWatcher για να αποφύγει έναν άπειρο βρόχο.
                    cvvEditText.setText(maskedText); // Ορίζει το EditText με το κείμενο με ***.
                    cvvEditText.setSelection(maskedText.length()); // Θέτει τη θέση του κέρσορα στο τέλος του κειμένου.
                    cvvEditText.addTextChangedListener(this); // Προσθέτει τον TextWatcher πίσω.
                }
            }
        });

        // Βρίσκει το EditText για την ημερομηνία λήξης
        expiryDateEditText = findViewById(R.id.expiryDateEditText); // Βρίσκει το EditText για την ημερομηνία λήξης από το layout.

        // Θέτει τον τύπο εισόδου σε αριθμό και το μέγιστο μήκος στους 7 χαρακτήρες για το EditText της ημερομηνίας λήξης
        expiryDateEditText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); // Θέτει τον τύπο εισόδου σε αριθμό για το EditText της ημερομηνίας λήξης.
        expiryDateEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)}); // Θέτει φίλτρα εισόδου για το EditText ώστε να επιτρέπει μόνο αριθμούς και να περιορίζει το μήκος στους 7 χαρακτήρες.

        // Προσθέτει TextWatcher για να μορφοποιεί την ημερομηνία λήξης ως MM/YYYY
        expiryDateEditText.addTextChangedListener(new TextWatcher() { // Προσθέτει έναν TextWatcher για να μορφοποιεί την ημερομηνία λήξης ως MM/YYYY.
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) { // Εκτελείται μετά την αλλαγή του κειμένου στο EditText.
                String text = s.toString(); // Λαμβάνει το τρέχον κείμενο του EditText.
                if (text.length() == 2 && !text.contains("/")) { // Αν το μήκος είναι 2 και δεν περιέχει "/", το προσθέτει.
                    text += "/";
                    expiryDateEditText.setText(text);
                    expiryDateEditText.setSelection(text.length()); // Θέτει τη θέση του κέρσορα στο τέλος.
                } else if (text.length() == 3 && !text.substring(2, 3).equals("/")) { // Αν το μήκος είναι 3 και το τρίτο χαρακτήρας δεν είναι "/", το προσθέτει.
                    String newText = text.substring(0, 2) + "/" + text.substring(2, 3);
                    expiryDateEditText.setText(newText);
                    expiryDateEditText.setSelection(newText.length()); // Θέτει τη θέση του κέρσορα στο τέλος.
                }
            }
        });

        // Βρίσκει την ομάδα ραδιοκουμπιών για τη μέθοδο πληρωμής
        RadioGroup paymentMethodRadioGroup = findViewById(R.id.paymentMethodRadioGroup); // Βρίσκει την ομάδα ραδιοκουμπιών για τη μέθοδο πληρωμής από το layout.

        // Προσθέτει ακροατή για να δείχνει/κρύβει το EditText για τον αριθμό κάρτας, το CCV και την ημερομηνία λήξης, ανάλογα με τη μέθοδο πληρωμής που επιλέγεται
        paymentMethodRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { // Προσθέτει ακροατή για την επιλογή μεθόδου πληρωμής.
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) { // Εκτελείται όταν αλλάζει η επιλεγμένη μέθοδος πληρωμής.
                if (checkedId == R.id.cashRadioButton) { // Αν επιλεχθεί η μέθοδος πληρωμής με μετρητά.
                    cardNumberEditText.setVisibility(View.GONE); // Κρύβει την είσοδο του αριθμού κάρτας.
                    cvvEditText.setVisibility(View.GONE); // Κρύβει την είσοδο του CCV.
                    expiryDateEditText.setVisibility(View.GONE); // Κρύβει την είσοδο της ημερομηνίας λήξης.
                } else if (checkedId == R.id.cardRadioButton) { // Αν επιλεχθεί η μέθοδος πληρωμής με κάρτα.
                    cardNumberEditText.setVisibility(View.VISIBLE); // Δείχνει την είσοδο του αριθμού κάρτας.
                    cvvEditText.setVisibility(View.VISIBLE); // Δείχνει την είσοδο του CCV.
                    expiryDateEditText.setVisibility(View.VISIBLE); // Δείχνει την είσοδο της ημερομηνίας λήξης.
                }
            }
        });

        // Χειρίζεται το κλικ στο κουμπί ολοκλήρωσης αγοράς
        ConstraintLayout checkoutButton1 = findViewById(R.id.checkoutButton1);
        checkoutButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ελέγχει την επιλεγμένη μέθοδο πληρωμής
                int selectedPaymentMethodId = paymentMethodRadioGroup.getCheckedRadioButtonId();

                if (selectedPaymentMethodId == R.id.cashRadioButton) {
                    // Εάν η μέθοδος πληρωμής είναι μετρητά, συνεχίζει την πληρωμή χωρίς επαλήθευση των στοιχείων της κάρτας
                    startActivity(new Intent(CartActivity.this, checkoutActivity.class));
                    return; // Έξοδος από τη μέθοδο για να αποφευχθεί η περαιτέρω επαλήθευση
                }

                // Εάν η μέθοδος πληρωμής είναι κάρτα, συνεχίζει με την επαλήθευση της κάρτας
                String cardNumber = cardNumberEditText.getText().toString().trim();
                String cvv = cvvEditText.getText().toString().trim();
                String date = expiryDateEditText.getText().toString().trim();

                // Ελέγχει αν ο αριθμός κάρτας έχει ακριβώς 16 ψηφία
                if (cardNumber.length() != 16) {
                    // Εμφάνιση μηνύματος ότι ο αριθμός της κάρτας πρέπει να έχει ακριβώς 16 ψηφία
                    Toast.makeText(CartActivity.this, "Card number must be 16 digits", Toast.LENGTH_SHORT).show();
                    return; // Έξοδος χωρίς να συνεχίσει τη διαδικασία checkout
                }

                // Έλεγχος της μορφής της ημερομηνίας (π.χ. ΜΜ/YYYY)
                if (!isValidDate(date)) {
                    // Εμφάνιση μηνύματος σφάλματος εάν η μορφή της ημερομηνίας δεν είναι έγκυρη
                    Toast.makeText(CartActivity.this, "Invalid date format. Please use MM/YYYY format", Toast.LENGTH_SHORT).show();
                    return; // Έξοδος χωρίς να συνεχίσει τη διαδικασία checkout
                }

                // Έλεγχος αν το CVV έχει ακριβώς 3 ψηφία
                if (cvv.length() != 3) {
                    // Εμφάνιση μηνύματος σφάλματος εάν το CVV δεν έχει ακριβώς 3 ψηφία
                    Toast.makeText(CartActivity.this, "CVV must be exactly 3 digits", Toast.LENGTH_SHORT).show();
                } else {
                    // Εάν όλα είναι εντάξει, συνεχίζει στη διαδικασία checkout
                    startActivity(new Intent(CartActivity.this, checkoutActivity.class));
                }
            }

        });
    }

    // Ελέγχει αν η μορφή της ημερομηνίας είναι έγκυρη (MM/YYYY)
    private boolean isValidDate(String date) {
        // Ελέγχει αν η ημερομηνία είναι null ή δεν έχει μήκος 7 χαρακτήρες
        if (date == null || date.length() != 7) {
            return false;
        }
        // Χωρίζει την ημερομηνία στα δύο μέρη με βάση το "/"
        String[] parts = date.split("/");
        if (parts.length != 2) {
            return false;
        }
        // Έλεγχος για τον μήνα (πρέπει να είναι από 01 έως 12)
        try {
            int month = Integer.parseInt(parts[0]);
            if (month < 1 || month > 12) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        // Έλεγχος για το έτος (πρέπει να είναι τουλάχιστον 2024)
        try {
            int year = Integer.parseInt(parts[1]);
            if (year < 2024) { // Εδώ ορίζεται η ελάχιστη δυνατή χρονική στιγμή
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    private void bottomNavigation() {
        // Αρχικοποιεί το κουμπί profileBtn και θέτει ακροατή κλικ για να επιστρέψει στο ProfileActivity
        LinearLayout profileBtn = findViewById(R.id.profileBtn); // Βρίσκει το κουμπί profileBtn από το layout
        if (profileBtn != null) { // Ελέγχει αν το profileBtn δεν είναι null
            profileBtn.setOnClickListener(new View.OnClickListener() { // Θέτει ακροατή κλικ στο κουμπί
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(CartActivity.this, ProfileActivity.class)); // Ξεκινά το ProfileActivity
                }
            });
        }

        // Αρχικοποιεί το κουμπί homeBtn και θέτει ακροατή κλικ για να επιστρέψει στο MainActivity
        LinearLayout homeBtn = findViewById(R.id.homeBtn); // Βρίσκει το κουμπί homeBtn από το layout
        if (homeBtn != null) { // Ελέγχει αν το homeBtn δεν είναι null
            homeBtn.setOnClickListener(new View.OnClickListener() { // Θέτει ακροατή κλικ στο κουμπί
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(CartActivity.this, MainActivity.class)); // Ξεκινά το MainActivity
                }
            });
        }

        // Αρχικοποιεί το κουμπί cartBtn και θέτει ακροατή κλικ
        LinearLayout cartBtn = findViewById(R.id.cartBtn); // Βρίσκει το κουμπί cartBtn από το layout
        if (cartBtn != null) { // Ελέγχει αν το cartBtn δεν είναι null
            cartBtn.setOnClickListener(new View.OnClickListener() { // Θέτει ακροατή κλικ στο κουμπί
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(CartActivity.this, CartActivity.class)); // Ξεκινά το CartActivity
                }
            });
        }

        // Αρχικοποιεί το κουμπί supportBtn και θέτει ακροατή κλικ για να ανοίξει το SupportActivity
        LinearLayout supportBtn = findViewById(R.id.supportBtn); // Βρίσκει το κουμπί supportBtn από το layout
        if (supportBtn != null) { // Ελέγχει αν το supportBtn δεν είναι null
            supportBtn.setOnClickListener(new View.OnClickListener() { // Θέτει ακροατή κλικ στο κουμπί
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(CartActivity.this, SupportActivity.class)); // Ξεκινά το SupportActivity
                }
            });
        }

        // Αρχικοποιεί το κουμπί settingsBtn και θέτει ακροατή κλικ για να πάει στο SettingsActivity
        LinearLayout settingsBtn = findViewById(R.id.settingsBtn); // Βρίσκει το κουμπί settingsBtn από το layout
        if (settingsBtn != null) { // Ελέγχει αν το settingsBtn δεν είναι null
            settingsBtn.setOnClickListener(new View.OnClickListener() { // Θέτει ακροατή κλικ στο κουμπί
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(CartActivity.this, SettingsActivity.class)); // Ξεκινά το SettingsActivity
                }
            });
        }
    }

    private void initList() {
        // Αρχικοποιεί τον LinearLayoutManager με κάθετη διάταξη
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false); // Αρχικοποιεί τον LinearLayoutManager με κάθετη διάταξη
        recyclerViewList.setLayoutManager(linearLayoutManager); // Θέτει τον LinearLayoutManager στο recyclerViewList

        // Αρχικοποιεί τον adapter με τη λίστα καλαθιού και την προσθήκη ChangeNumberItemsListener
        adapter = new CartListAdapter(managementCart.getListCart(), this, new ChangeNumberItemsListener() { // Αρχικοποιεί τον adapter με τη λίστα καλαθιού
            @Override
            public void changed() {
                calculateCard(); // Καλεί τη μέθοδο calculateCard όταν αλλάξει κάτι στο καλάθι
            }
        });

        // Θέτει τον adapter στο recyclerViewList
        recyclerViewList.setAdapter(adapter); // Θέτει τον adapter στο recyclerViewList
        if (managementCart.getListCart().isEmpty()) { // Ελέγχει αν το καλάθι είναι άδειο
            emptyTxt.setVisibility(View.VISIBLE); // Εμφανίζει το emptyTxt
            scrollView.setVisibility(View.GONE); // Κρύβει το scrollView
        } else {
            emptyTxt.setVisibility(View.GONE); // Κρύβει το emptyTxt
            scrollView.setVisibility(View.VISIBLE); // Εμφανίζει το scrollView
        }
    }

    @SuppressLint("SetTextI18n")
    private void calculateCard() {
        double percentTax = 0.02;
        double delivery = 5;

        // Υπολογίζει τον φόρο, το σύνολο και το συνολικό ποσό των αντικειμένων
        tax = Math.round((managementCart.getTotalFee() * percentTax) * 100.0) / 100.0; // Υπολογίζει τον φόρο
        double total = Math.round((managementCart.getTotalFee() + tax + delivery) * 100.0) / 100.0; // Υπολογίζει το συνολικό ποσό με τον φόρο και την παράδοση
        double itemTotal = Math.round(managementCart.getTotalFee() * 100.0) / 100.0; // Υπολογίζει το συνολικό ποσό των αντικειμένων

        // Εμφανίζει τα ποσά στα αντίστοιχα TextView
        totalFeeTxt.setText("$" + itemTotal); // Εμφανίζει το συνολικό ποσό των αντικειμένων
        taxTxt.setText("$" + tax); // Εμφανίζει τον φόρο
        deliverytxt.setText("$" + delivery); // Εμφανίζει το κόστος παράδοσης
        totalTxt.setText("$" + total); // Εμφανίζει το συνολικό ποσό
    }

    private void initView() {
        // Αρχικοποιεί τα TextView και άλλα στοιχεία του layout
        totalFeeTxt = findViewById(R.id.totalFeeTxt); // Βρίσκει το TextView totalFeeTxt από το layout
        taxTxt = findViewById(R.id.taxTxt); // Βρίσκει το TextView taxTxt από το layout
        deliverytxt = findViewById(R.id.deliveryTxt); // Βρίσκει το TextView deliverytxt από το layout
        totalTxt = findViewById(R.id.totalTxt); // Βρίσκει το TextView totalTxt από το layout
        recyclerViewList = findViewById(R.id.view); // Βρίσκει το RecyclerView recyclerViewList από το layout
        scrollView = findViewById(R.id.scrollView); // Βρίσκει το ScrollView scrollView από το layout
        emptyTxt = findViewById(R.id.emptyTxt); // Βρίσκει το TextView emptyTxt από το layout
    }
}

