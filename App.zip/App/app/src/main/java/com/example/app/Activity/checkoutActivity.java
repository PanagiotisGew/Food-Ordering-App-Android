package com.example.app.Activity; // Δηλώνουμε το πακέτο της κλάσης

import android.content.Intent; // Εισάγουμε την κλάση Intent για να ξεκινήσουμε μια νέα δραστηριότητα
import android.os.Bundle; // Εισάγουμε την κλάση Bundle για να αποθηκεύσουμε την κατάσταση της δραστηριότητας
import android.view.View; // Εισάγουμε την κλάση View για να χειριστούμε τα οπτικά στοιχεία της διεπαφής
import android.widget.LinearLayout; // Εισάγουμε την κλάση LinearLayout για να χρησιμοποιήσουμε γραμμικές διατάξεις

import androidx.appcompat.app.AppCompatActivity; // Εισάγουμε την κλάση AppCompatActivity για να χρησιμοποιήσουμε συμβατές λειτουργίες δραστηριότητας
import androidx.constraintlayout.widget.ConstraintLayout; // Εισάγουμε την κλάση ConstraintLayout για να χρησιμοποιήσουμε διάταξη με περιορισμούς

import com.example.app.Helper.ManagementCart; // Εισάγουμε την κλάση ManagementCart για να διαχειριστούμε το καλάθι αγορών
import com.example.app.R; // Εισάγουμε την κλάση R για να έχουμε πρόσβαση στους πόρους της εφαρμογής (όπως layout και IDs)

public class checkoutActivity extends AppCompatActivity { // Δηλώνουμε την κλάση checkoutActivity που επεκτείνει την AppCompatActivity

    // Δηλώνουμε μεταβλητή για τη διαχείριση του καλαθιού
    private ManagementCart managementCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Δημιουργούμε τη μέθοδο onCreate που καλείται κατά τη δημιουργία της δραστηριότητας
        super.onCreate(savedInstanceState); // Καλούμε τη μέθοδο onCreate της υπερκλάσης
        setContentView(R.layout.activity_checkout); // Ορίζουμε το layout της δραστηριότητας με το αρχείο activity_checkout.xml

        // Αρχικοποιούμε τη μεταβλητή της διαχείρισης του καλαθιού
        managementCart = new ManagementCart(this);

        // Αρχικοποιούμε το κουμπί homeBtn2 και προσθέτουμε click listener για επιστροφή στο MainActivity
        ConstraintLayout startBtn1 = findViewById(R.id.homeBtn2); // Βρίσκουμε το στοιχείο με το ID homeBtn2 στο layout
        if (startBtn1 != null) { // Ελέγχουμε αν το στοιχείο βρέθηκε
            startBtn1.setOnClickListener(new View.OnClickListener() { // Προσθέτουμε ένα OnClickListener στο κουμπί
                @Override
                public void onClick(View v) { // Ορίζουμε τη μέθοδο που θα κληθεί όταν το κουμπί πατηθεί
                    // Καθαρίζουμε το καλάθι πριν επιστρέψουμε στο MainActivity
                    managementCart.clearCart(); // Καθαρίζουμε το καλάθι αγορών
                    startActivity(new Intent(checkoutActivity.this, MainActivity.class)); // Ξεκινάμε το MainActivity
                }
            });
        }
    }
}