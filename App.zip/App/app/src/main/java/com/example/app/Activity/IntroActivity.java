package com.example.app.Activity; // Πακέτο της δραστηριότητας της εφαρμογής

import android.content.Intent; // Εισαγωγή κλάσης Intent για να ξεκινήσουμε νέα δραστηριότητα
import android.os.Bundle; // Εισαγωγή κλάσης Bundle για τη διαχείριση δεδομένων
import android.view.View; // Εισαγωγή κλάσης View για τη διαχείριση γραφικών στοιχείων

import androidx.appcompat.app.AppCompatActivity; // Εισαγωγή κλάσης AppCompatActivity για βασική δραστηριότητα
import androidx.constraintlayout.widget.ConstraintLayout; // Εισαγωγή κλάσης ConstraintLayout για τη διαχείριση διάταξης

import com.example.app.R; // Εισαγωγή του πόρου R για την πρόσβαση στους πόρους της εφαρμογής

public class IntroActivity extends AppCompatActivity { // Δήλωση της κλάσης IntroActivity ως υποκλάση της AppCompatActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Υλοποίηση της μεθόδου onCreate
        super.onCreate(savedInstanceState); // Κλήση της υλοποίησης της μεθόδου onCreate της υπερκλάσης
        setContentView(R.layout.activity_intro); // Ορισμός του περιεχομένου της δραστηριότητας από το αρχείο διάταξης XML

        ConstraintLayout startBtn=findViewById(R.id.checkoutButton1); // Εύρεση του κουμπιού εκκίνησης με βάση το ID του από το layout XML

        startBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή κλικ για το κουμπί εκκίνησης
            @Override
            public void onClick(View v) { // Υλοποίηση της μεθόδου onClick
                startActivity(new Intent(IntroActivity.this, MainActivity.class)); // Εκκίνηση νέας δραστηριότητας
            }
        });
    }
}
