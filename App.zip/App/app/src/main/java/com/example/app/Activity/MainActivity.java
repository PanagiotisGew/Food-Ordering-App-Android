package com.example.app.Activity; // Ορισμός του πακέτου της εφαρμογής

import android.content.Intent; // Εισαγωγή της κλάσης Intent για την εναλλαγή δραστηριοτήτων
import android.os.Bundle; // Εισαγωγή της κλάσης Bundle για τη διαχείριση της κατάστασης
import android.text.Editable; // Εισαγωγή της κλάσης Editable για τη διαχείριση κειμένου
import android.text.TextWatcher; // Εισαγωγή της κλάσης TextWatcher για την παρακολούθηση αλλαγών στο κείμενο
import android.view.View; // Εισαγωγή της κλάσης View για τη διαχείριση προβολών
import android.widget.EditText; // Εισαγωγή της κλάσης EditText για τη διαχείριση επεξεργάσιμων πεδίων κειμένου
import android.widget.LinearLayout; // Εισαγωγή της κλάσης LinearLayout για τη διάταξη προβολών
import android.widget.Toast; // Εισαγωγή της κλάσης Toast για την εμφάνιση μηνυμάτων στην οθόνη

import androidx.appcompat.app.AppCompatActivity; // Εισαγωγή της κλάσης AppCompatActivity για τη διαχείριση δραστηριοτήτων
import androidx.recyclerview.widget.LinearLayoutManager; // Εισαγωγή της κλάσης LinearLayoutManager για τη διάταξη του RecyclerView
import androidx.recyclerview.widget.RecyclerView; // Εισαγωγή της κλάσης RecyclerView για τη διαχείριση λιστών δεδομένων

import com.example.app.Adapter.CategoryAdapter; // Εισαγωγή της κλάσης CategoryAdapter για τη διαχείριση των κατηγοριών
import com.example.app.Adapter.RecommendedAdapter; // Εισαγωγή της κλάσης RecommendedAdapter για τη διαχείριση των προτεινόμενων ειδών
import com.example.app.Domain.CategoryDomain; // Εισαγωγή της κλάσης CategoryDomain για τη διαχείριση των δεδομένων κατηγοριών
import com.example.app.Domain.FoodDomain; // Εισαγωγή της κλάσης FoodDomain για τη διαχείριση των δεδομένων τροφίμων
import com.example.app.R; // Εισαγωγή της κλάσης R για τη διαχείριση των πόρων της εφαρμογής

import java.util.ArrayList; // Εισαγωγή της κλάσης ArrayList για τη διαχείριση λιστών δεδομένων

public class MainActivity extends AppCompatActivity { // Ορισμός της κύριας δραστηριότητας
    private RecyclerView.Adapter adapter, adapter2; // Δήλωση μεταβλητών για τα adapters των RecyclerViews
    private RecyclerView recyclerViewCategotyList, recyclerViewPopularlist; // Δήλωση μεταβλητών για τα RecyclerViews
    private EditText editText; // Δήλωση μεταβλητής EditText

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Μέθοδος που καλείται κατά τη δημιουργία της δραστηριότητας
        super.onCreate(savedInstanceState); // Κλήση της υπερκλάσης
        setContentView(R.layout.activity_main); // Ορισμός του layout της δραστηριότητας

        recyclerViewCategoty(); // Κλήση της μεθόδου για την αρχικοποίηση του RecyclerView κατηγοριών
        recyclerViewPopularlist(); // Κλήση της μεθόδου για την αρχικοποίηση του RecyclerView δημοφιλών ειδών
        bottomNavigation(); // Κλήση της μεθόδου για τη διαχείριση της κάτω πλοήγησης

        // Αρχικοποίηση του EditText
        editText = findViewById(R.id.editTextText3);
        // Προσθήκη TextChangedListener στο EditText
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Μετατροπή του κειμένου σε πεζά και αφαίρεση κενών
                String searchTextTrimmed = s.toString().toLowerCase().replaceAll("\\s", "");
                // Έλεγχος αν το κείμενο περιέχει κάποιο από τα συγκεκριμένα τρόφιμα
                if (searchTextTrimmed.contains("pepperonipizza") || searchTextTrimmed.contains("cheeseburger") || searchTextTrimmed.contains("vegetablepizza") || searchTextTrimmed.contains("hotdog") || searchTextTrimmed.contains("deluxeburger") || searchTextTrimmed.contains("tacos") || searchTextTrimmed.contains("souvlaki") || searchTextTrimmed.contains("icecream") || searchTextTrimmed.contains("milkshake") || searchTextTrimmed.contains("donut") || searchTextTrimmed.contains("cocacola") || searchTextTrimmed.contains("fanta") || searchTextTrimmed.contains("water")) {
                    // Εμφάνιση μηνύματος Toast που δείχνει ότι το προϊόν είναι διαθέσιμο
                    Toast.makeText(MainActivity.this, "We have this product. Go select it from our recommended dishes", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void bottomNavigation() { // Μέθοδος για τη διαχείριση της κάτω πλοήγησης
        LinearLayout homeBtn = findViewById(R.id.homeBtn); // Αρχικοποίηση του κουμπιού για το σπίτι
        LinearLayout cartBtn = findViewById(R.id.cartBtn); // Αρχικοποίηση του κουμπιού για το καλάθι
        LinearLayout profileBtn = findViewById(R.id.profileBtn); // Αρχικοποίηση του κουμπιού για το προφίλ
        LinearLayout supportBtn = findViewById(R.id.supportBtn); // Αρχικοποίηση του κουμπιού για την υποστήριξη
        LinearLayout settingsBtn = findViewById(R.id.settingsBtn); // Αρχικοποίηση του κουμπιού για τις ρυθμίσεις

        homeBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί σπίτι
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MainActivity.class)); // Μετάβαση στην κύρια δραστηριότητα
            }
        });

        cartBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί καλάθι
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CartActivity.class)); // Μετάβαση στη δραστηριότητα καλαθιού
            }
        });

        profileBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί προφίλ
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ProfileActivity.class)); // Μετάβαση στη δραστηριότητα προφίλ
            }
        });

        supportBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί υποστήριξη
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SupportActivity.class)); // Μετάβαση στη δραστηριότητα υποστήριξης
            }
        });

        settingsBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί ρυθμίσεις
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class)); // Μετάβαση στη δραστηριότητα ρυθμίσεων
            }
        });
    }

    private void recyclerViewPopularlist() { // Μέθοδος για την αρχικοποίηση του RecyclerView δημοφιλών ειδών
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false); // Ορισμός του LinearLayoutManager
        recyclerViewPopularlist = findViewById(R.id.view2); // Σύνδεση του RecyclerView με το layout
        recyclerViewPopularlist.setLayoutManager(linearLayoutManager); // Ορισμός του LayoutManager στο RecyclerView

        ArrayList<FoodDomain> foodlist = new ArrayList<>(); // Δημιουργία λίστας με τρόφιμα
        foodlist.add(new FoodDomain("Pepperoni Pizza", "pizza1", "Slices Pepperoni, Mozzarella Cheese, Fresh Oregano, Ground Black Pepper, Pizza Sauce", 13.0, 5, 20, 1000));
        foodlist.add(new FoodDomain("CheeseBurger", "burger", "Beef, Gouda Cheese, Special Sauce, Lettuce, Tomato ", 15.20, 4, 18, 1500));
        foodlist.add(new FoodDomain("Vegetable Pizza", "pizza3", "Olive oli, Vegetable Oil, Pitted Kalamata, Cherry Tomatoes, Fresh Oregano, Basil", 11.0, 3, 16, 800));
        foodlist.add(new FoodDomain("HotDog", "cat_3", "Frankfurt sausage, Ketchup, Mustard, Βrioche Βun", 9.0, 5, 8, 800));
        foodlist.add(new FoodDomain("Deluxe Burger", "burger_icon", "400gr Beef, Cheddar, Tomato, Mayo Sauce, Lettuce, Brioche Bun, French Fries", 15.0, 5, 20, 1500));
        foodlist.add(new FoodDomain("Tacos", "tacos", "Beef, Lettuce, Tomato, Guacamole, Onions", 11.0, 4, 16, 900));
        foodlist.add(new FoodDomain("Souvlaki", "souvlaki1", "Chicken Souvalki, Tomato, Tzatziki, Onions, French Fries", 7.50, 5, 10, 1000));
        foodlist.add(new FoodDomain("Ice Cream", "xonaki", "2 Balls Of Strawberry Flavour Ice Cream", 5.0, 4, 3, 800));
        foodlist.add(new FoodDomain("Ice Cream", "icecreamksilo", "Ice Cream With Banana And Chocolate Coating", 6.0, 5, 1, 800));
        foodlist.add(new FoodDomain("Milkshake", "milkshake", "Chocolate Milk Shake With Whipped Cream", 8.0, 5, 10, 1000));
        foodlist.add(new FoodDomain("Donut", "donutroz", "Chocolate Donut With Strawberry Coating", 6.0, 5, 10, 700));
        foodlist.add(new FoodDomain("CocaCola", "cocacola", "Iced Coca Cola 500ml", 4.0, 5, 1, 600));
        foodlist.add(new FoodDomain("Fanta", "fanta", "Iced Fanta 500ml", 4.0, 5, 1, 600));
        foodlist.add(new FoodDomain("Water", "water", "Mineral Bottle Of Water 500ml", 2.0, 5, 1, 0));

        adapter2 = new RecommendedAdapter(foodlist); // Δημιουργία του adapter με τη λίστα των τροφίμων
        recyclerViewPopularlist.setAdapter(adapter2); // Σύνδεση του adapter με το RecyclerView
    }

    private void recyclerViewCategoty() { // Μέθοδος για την αρχικοποίηση του RecyclerView κατηγοριών
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false); // Ορισμός του LinearLayoutManager
        recyclerViewCategotyList = findViewById(R.id.view1); // Σύνδεση του RecyclerView με το layout
        recyclerViewCategotyList.setLayoutManager(linearLayoutManager); // Ορισμός του LayoutManager στο RecyclerView

        ArrayList<CategoryDomain> categoryList = new ArrayList<>(); // Δημιουργία λίστας με κατηγορίες
        categoryList.add(new CategoryDomain("Pizza", "cat_1"));
        categoryList.add(new CategoryDomain("Burger", "cat_2"));
        categoryList.add(new CategoryDomain("Hotdog", "cat_3"));
        categoryList.add(new CategoryDomain("Drink", "cat_4"));
        categoryList.add(new CategoryDomain("Donut", "cat_5"));

        adapter = new CategoryAdapter(categoryList); // Δημιουργία του adapter με τη λίστα των κατηγοριών
        recyclerViewCategotyList.setAdapter(adapter); // Σύνδεση του adapter με το RecyclerView
    }
}
