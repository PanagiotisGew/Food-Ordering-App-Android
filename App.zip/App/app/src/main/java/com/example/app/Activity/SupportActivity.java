package com.example.app.Activity; // Ορισμός του πακέτου της εφαρμογής

import android.content.Intent; // Εισαγωγή της κλάσης Intent για την εναλλαγή δραστηριοτήτων
import android.os.Bundle; // Εισαγωγή της κλάσης Bundle για τη διαχείριση της κατάστασης
import android.view.View; // Εισαγωγή της κλάσης View για τη διαχείριση προβολών
import android.widget.LinearLayout; // Εισαγωγή της κλάσης LinearLayout για τη διάταξη προβολών

import androidx.appcompat.app.AppCompatActivity; // Εισαγωγή της κλάσης AppCompatActivity για τη διαχείριση δραστηριοτήτων

import com.example.app.R; // Εισαγωγή της κλάσης R για τη διαχείριση των πόρων της εφαρμογής

public class SupportActivity extends AppCompatActivity { // Ορισμός της δραστηριότητας υποστήριξης

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Μέθοδος που καλείται κατά τη δημιουργία της δραστηριότητας
        super.onCreate(savedInstanceState); // Κλήση της υπερκλάσης
        setContentView(R.layout.activity_support); // Ορισμός του layout της δραστηριότητας

        // Αρχικοποίηση του κουμπιού υποστήριξης και ορισμός ακροατή κλικ
        LinearLayout supportBtn = findViewById(R.id.supportBtn);
        if (supportBtn != null) { // Έλεγχος αν το κουμπί δεν είναι null
            supportBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί υποστήριξης
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SupportActivity.this, SupportActivity.class)); // Μετάβαση στη δραστηριότητα υποστήριξης
                }
            });
        }

        // Αρχικοποίηση του κουμπιού προφίλ και ορισμός ακροατή κλικ για επιστροφή στη δραστηριότητα προφίλ
        LinearLayout profileBtn = findViewById(R.id.profileBtn);
        if (profileBtn != null) { // Έλεγχος αν το κουμπί δεν είναι null
            profileBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί προφίλ
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SupportActivity.this, ProfileActivity.class)); // Μετάβαση στη δραστηριότητα προφίλ
                }
            });
        }

        // Αρχικοποίηση του κουμπιού σπιτιού και ορισμός ακροατή κλικ για επιστροφή στη κύρια δραστηριότητα
        LinearLayout homeBtn = findViewById(R.id.homeBtn);
        if (homeBtn != null) { // Έλεγχος αν το κουμπί δεν είναι null
            homeBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί σπιτιού
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SupportActivity.this, MainActivity.class)); // Μετάβαση στη κύρια δραστηριότητα
                }
            });
        }

        // Αρχικοποίηση του κουμπιού καλαθιού και ορισμός ακροατή κλικ για μετάβαση στη δραστηριότητα καλαθιού
        LinearLayout cartBtn = findViewById(R.id.cartBtn);
        if (cartBtn != null) { // Έλεγχος αν το κουμπί δεν είναι null
            cartBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί καλαθιού
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SupportActivity.this, CartActivity.class)); // Μετάβαση στη δραστηριότητα καλαθιού
                }
            });
        }

        // Αρχικοποίηση του κουμπιού ρυθμίσεων και ορισμός ακροατή κλικ για μετάβαση στη δραστηριότητα ρυθμίσεων
        LinearLayout settingsBtn = findViewById(R.id.settingsBtn);
        if (settingsBtn != null) { // Έλεγχος αν το κουμπί δεν είναι null
            settingsBtn.setOnClickListener(new View.OnClickListener() { // Ορισμός ακροατή για το κουμπί ρυθμίσεων
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SupportActivity.this, SettingsActivity.class)); // Μετάβαση στη δραστηριότητα ρυθμίσεων
                }
            });
        }
    }
}