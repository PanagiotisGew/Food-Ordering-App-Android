package com.example.app.Domain;

import java.io.Serializable;

public class FoodDomain  implements Serializable {
    private String title;  // Τίτλος του φαγητού
    private String pic;  // Διαδρομή της εικόνας του φαγητού
    private String description;  // Περιγραφή του φαγητού
    private Double fee;  // Κόστος του φαγητού
    private int star;  // Αξιολόγηση του φαγητού σε αστέρια
    private int time;  // Χρόνος προετοιμασίας του φαγητού σε λεπτά
    private int calories;  // Θερμίδες του φαγητού
    private int numberInCart;  // Πλήθος του φαγητού που βρίσκεται στο καλάθι αγορών

    public FoodDomain(String title, String pic, String description, Double fee, int star, int time, int calories) {
        // Αρχικοποίηση του τίτλου του φαγητού
        this.title = title;
        // Αρχικοποίηση της διαδρομής της εικόνας του φαγητού
        this.pic = pic;
        // Αρχικοποίηση της περιγραφής του φαγητού
        this.description = description;
        // Αρχικοποίηση του κόστους του φαγητού
        this.fee = fee;
        // Αρχικοποίηση της αξιολόγησης του φαγητού σε αστέρια
        this.star = star;
        // Αρχικοποίηση του χρόνου προετοιμασίας του φαγητού
        this.time = time;
        // Αρχικοποίηση των θερμίδων του φαγητού
        this.calories = calories;
    }

    public int getNumberInCart() {
        return numberInCart;
    }

    public void setNumberInCart(int numberInCart) {
        this.numberInCart = numberInCart;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getFee() {
        return fee;
    }

    public void setFee(Double fee) {
        this.fee = fee;
    }

    public int getStar() {
        return star;
    }

    public void setStar(int star) {
        this.star = star;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

}
