package com.example.app.Domain; // Πακέτο που περιέχει το Domain των κατηγοριών

public class CategoryDomain {
    private String title; // Τίτλος της κατηγορίας
    private String pic; // Όνομα της εικόνας της κατηγορίας

    // Constructor
    public CategoryDomain(String title, String pic) {
        this.title = title;
        this.pic = pic;
    }

    // Μέθοδος getter για τον τίτλο
    public String getTitle() {
        return title;
    }

    // Μέθοδος setter για τον τίτλο
    public void setTitle(String title) {
        this.title = title;
    }

    // Μέθοδος getter για την εικόνα
    public String getPic() {
        return pic;
    }

    // Μέθοδος setter για την εικόνα
    public void setPic(String pic) {
        this.pic = pic;
    }
}