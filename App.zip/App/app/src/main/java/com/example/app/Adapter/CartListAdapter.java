package com.example.app.Adapter; // Πακέτο που περιέχει τον Adapter

import android.content.Context; // Περιέχει κλάσεις που αφορούν το Context της εφαρμογής
import android.view.LayoutInflater; // Χρησιμοποιείται για να "φουσκώσει" το layout από ένα αρχείο XML
import android.view.View; // Βασική κλάση για το UI
import android.view.ViewGroup; // Ομάδα παιδιών του layout
import android.widget.ImageView; // ImageView για εικόνες
import android.widget.TextView; // TextView για κείμενο

import androidx.annotation.NonNull; // Αναφορά στην ανακατασκευή
import androidx.recyclerview.widget.RecyclerView; // Βιβλιοθήκη για τον RecyclerView

import com.bumptech.glide.Glide; // Φόρτωση εικόνων
import com.example.app.Domain.FoodDomain; // Δική μας κλάση που αφορά το domain των τροφίμων
import com.example.app.Helper.ManagementCart; // Βοηθητική κλάση για τη διαχείριση του καλαθιού
import com.example.app.Interface.ChangeNumberItemsListener; // Ακροατής για αλλαγές στον αριθμό των αντικειμένων
import com.example.app.R; // Αναφορά στο R.java που περιέχει τα αναγνωριστικά των πόρων της εφαρμογής

import java.util.ArrayList; // Χρησιμοποιείται για να δηλώσει μια συλλογή λίστας


public class CartListAdapter extends RecyclerView.Adapter<CartListAdapter.ViewHolder> {
    ArrayList<FoodDomain> listFoodSelected; // Λίστα επιλεγμένων τροφίμων
    private ManagementCart managementCart; // Διαχείριση του καλαθιού
    ChangeNumberItemsListener changeNumberItemsListener; // Ακροατής για αλλαγές στον αριθμό των αντικειμένων

    // Constructor
    public CartListAdapter(ArrayList<FoodDomain> listFoodSelected, Context context, ChangeNumberItemsListener changeNumberItemsListener) {
        this.listFoodSelected = listFoodSelected;
        managementCart = new ManagementCart(context);
        this.changeNumberItemsListener = changeNumberItemsListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Δημιουργία νέας προβολής βάσει του layout viewholder_cart.xml
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_cart, parent, false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Ορισμός των τιμών στα αντίστοιχα στοιχεία της προβολής
        holder.title.setText(listFoodSelected.get(position).getTitle());
        holder.feeEachItem.setText("$" + listFoodSelected.get(position).getFee());
        holder.totalEachItem.setText("$" + Math.round((listFoodSelected.get(position).getNumberInCart() * listFoodSelected.get(position).getFee())));
        holder.num.setText(String.valueOf(listFoodSelected.get(position).getNumberInCart()));

        // Φόρτωση εικόνας χρησιμοποιώντας το Glide
        int drawableReourceId = holder.itemView.getContext().getResources()
                .getIdentifier(listFoodSelected.get(position).getPic(), "drawable",
                        holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext())
                .load(drawableReourceId)
                .into(holder.pic);

        // Ακροάτης για το κουμπί "Προσθήκη"
        holder.plusItem.setOnClickListener(v -> managementCart.plusNumberFood(listFoodSelected, position, () -> {
            notifyDataSetChanged();
            changeNumberItemsListener.changed();
        }));

        // Ακροάτης για το κουμπί "Αφαίρεση"
        holder.minusItem.setOnClickListener(v -> managementCart.minusNumberFood(listFoodSelected, position, () -> {
            notifyDataSetChanged();
            changeNumberItemsListener.changed();
        }));
    }

    @Override
    public int getItemCount() {
        return listFoodSelected.size();
    }

    // Εσωτερική κλάση ViewHolder
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, feeEachItem; // Τίτλος και τιμή ανά αντικείμενο
        ImageView pic, plusItem, minusItem; // Εικόνα και κουμπιά για προσθήκη και αφαίρεση
        TextView totalEachItem, num; // Συνολική τιμή ανά αντικείμενο και αριθμός αντικειμένων

        // Constructor
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Ανάθεση στοιχείων από το layout
            title = itemView.findViewById(R.id.titleTxt);
            pic = itemView.findViewById(R.id.pic);
            feeEachItem = itemView.findViewById(R.id.feeEachItem);
            totalEachItem = itemView.findViewById(R.id.totalEachItem);
            plusItem = itemView.findViewById(R.id.plusCardBtn);
            minusItem = itemView.findViewById(R.id.minusCardBtn);
            num = itemView.findViewById(R.id.numberItemTxt);
        }
    }
}