package com.example.app.Interface; // Πακέτο της διεπαφής

public interface ChangeNumberItemsListener { // Δήλωση της διεπαφής ChangeNumberItemsListener
    void changed(); // Μέθοδος για την αλλαγή αντικειμένων
}