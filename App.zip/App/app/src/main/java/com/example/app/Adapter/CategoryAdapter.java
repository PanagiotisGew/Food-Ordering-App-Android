package com.example.app.Adapter; // Πακέτο του προσαρμογέα (adapter)

import android.view.LayoutInflater; // Εισαγωγή κλάσης LayoutInflater για τη δημιουργία αντικειμένων View
import android.view.View; // Εισαγωγή κλάσης View για τη διαχείριση γραφικών στοιχείων
import android.view.ViewGroup; // Εισαγωγή κλάσης ViewGroup για τη διαχείριση ομάδων γραφικών στοιχείων
import android.widget.ImageView; // Εισαγωγή κλάσης ImageView για τη διαχείριση εικόνων
import android.widget.TextView; // Εισαγωγή κλάσης TextView για τη διαχείριση κειμένου

import androidx.annotation.NonNull; // Εισαγωγή αναφοράς στη βιβλιοθήκη υποστήριξης (support library)
import androidx.constraintlayout.widget.ConstraintLayout; // Εισαγωγή κλάσης ConstraintLayout για τη διαχείριση του στοιχείου σχεδίασης
import androidx.recyclerview.widget.RecyclerView; // Εισαγωγή κλάσης RecyclerView για τη διαχείριση λίστας προβολής

import com.bumptech.glide.Glide; // Εισαγωγή κλάσης Glide για τη διαχείριση εικόνων
import com.example.app.Domain.CategoryDomain; // Εισαγωγή κλάσης CategoryDomain από το domain της εφαρμογής
import com.example.app.R; // Εισαγωγή του πόρου R για την πρόσβαση στους πόρους της εφαρμογής

import java.util.ArrayList; // Εισαγωγή κλάσης ArrayList για τη διαχείριση λιστών αντικειμένων

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> { // Δήλωση της κλάσης CategoryAdapter ως προσαρμογέα RecyclerView
    ArrayList<CategoryDomain> categoryDomains; // Δήλωση λίστας categoryDomains τύπου CategoryDomain για τις κατηγορίες

    public CategoryAdapter(ArrayList<CategoryDomain> categoryDomains) { // Κατασκευαστής με ορίσματα
        this.categoryDomains = categoryDomains; // Αρχικοποίηση της λίστας κατηγοριών με τις παρεχόμενες κατηγορίες
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { // Υλοποίηση της μεθόδου onCreateViewHolder
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_category, parent, false); // Δημιουργία νέου αντικειμένου View από το αρχείο διάταξης XML

        return new ViewHolder(inflate);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) { // Υλοποίηση της μεθόδου onBindViewHolder
        holder.categoryName.setText(categoryDomains.get(position).getTitle()); // Ορισμός του κειμένου της κατηγορίας στο αντίστοιχο TextView
        String picUrl = ""; // Αρχικοποίηση του URL για τη φωτογραφία της κατηγορίας
        switch (position) { // Έλεγχος της θέσης της κατηγορίας
            case 0: // Σε περίπτωση θέσης 0
                picUrl = "cat_1"; // Ορισμός του URL για την πρώτη κατηγορία
                break;
            case 1: // Σε περίπτωση θέσης 1
                picUrl = "cat_2"; // Ορισμός του URL για τη δεύτερη κατηγορία
                break;
            case 2: // Σε περίπτωση θέσης 2
                picUrl = "cat_3"; // Ορισμός του URL για την τρίτη κατηγορία
                break;
            case 3: // Σε περίπτωση θέσης 3
                picUrl = "cat_4"; // Ορισμός του URL για την τέταρτη κατηγορία
                break;
            case 4: // Σε περίπτωση θέσης 4
                picUrl = "cat_5"; // Ορισμός του URL για την πέμπτη κατηγορία
                break;
        }

        int drawableReourceId = holder.itemView.getContext().getResources() // Εύρεση του αναγνωριστικού πόρου της εικόνας
                .getIdentifier(picUrl, "drawable",
                        holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext()) // Φόρτωση της εικόνας με χρήση της βιβλιοθήκης Glide
                .load(drawableReourceId) // Φόρτωση της εικόνας με το συγκεκριμένο αναγνωριστικό πόρου
                .into(holder.categoryPic); // Εισαγωγή της εικόνας στο ImageView
    }

    @Override
    public int getItemCount() { return categoryDomains.size(); } // Επιστροφή του μεγέθους της λίστας κατηγοριών

    public class ViewHolder extends RecyclerView.ViewHolder { // Δήλωση της εσωτερικής κλάσης ViewHolder
        TextView categoryName; // Δήλωση μεταβλητής categoryName τύπου TextView για την ονομασία της κατηγορίας
        ImageView categoryPic; // Δήλωση μεταβλητής categoryPic τύπου ImageView για τη φωτογραφία της κατηγορίας
        ConstraintLayout mainLayout; // Δήλωση μεταβλητής mainLayout τύπου ConstraintLayout για το κυρίως layout

        public ViewHolder(@NonNull View itemView) { // Κατασκευαστής με ορίσματα
            super(itemView); // Κλήση του κατασκευαστή της υπερκλάσης
            categoryName = itemView.findViewById(R.id.categoryName); // Ανάθεση αναγνωριστικού TextView
            categoryPic = itemView.findViewById(R.id.categoryPic); // Ανάθεση αναγνωριστικού ImageView
            mainLayout = itemView.findViewById(R.id.mainLayout); // Ανάθεση αναγνωριστικού ConstraintLayout
        }
    }
}

