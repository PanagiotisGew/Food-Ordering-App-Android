package com.example.app.Adapter; // Πακέτο του προσαρμογέα (adapter)

import android.content.Intent; // Εισαγωγή κλάσης Intent για τη μετάβαση σε άλλη δραστηριότητα
import android.view.LayoutInflater; // Εισαγωγή κλάσης LayoutInflater για τη δημιουργία αντικειμένων View
import android.view.View; // Εισαγωγή κλάσης View για τη διαχείριση γραφικών στοιχείων
import android.view.ViewGroup; // Εισαγωγή κλάσης ViewGroup για τη διαχείριση ομάδων γραφικών στοιχείων
import android.widget.ImageView; // Εισαγωγή κλάσης ImageView για τη διαχείριση εικόνων
import android.widget.TextView; // Εισαγωγή κλάσης TextView για τη διαχείριση κειμένου

import androidx.annotation.NonNull; // Εισαγωγή αναφοράς στη βιβλιοθήκη υποστήριξης (support library)
import androidx.recyclerview.widget.RecyclerView; // Εισαγωγή κλάσης RecyclerView για τη διαχείριση λίστας προβολής
import com.bumptech.glide.Glide; // Εισαγωγή κλάσης Glide για τη διαχείριση εικόνων
import com.example.app.Activity.ShowDetailActivity; // Εισαγωγή κλάσης ShowDetailActivity για την εμφάνιση λεπτομερειών ενός αντικειμένου
import com.example.app.Domain.FoodDomain; // Εισαγωγή κλάσης FoodDomain από το domain της εφαρμογής
import com.example.app.R; // Εισαγωγή του πόρου R για την πρόσβαση στους πόρους της εφαρμογής

import java.util.ArrayList; // Εισαγωγή κλάσης ArrayList για τη διαχείριση λιστών αντικειμένων

public class RecommendedAdapter extends RecyclerView.Adapter<RecommendedAdapter.ViewHolder> { // Δήλωση της κλάσης RecommendedAdapter ως προσαρμογέα RecyclerView
    ArrayList<FoodDomain> RecommendedDomains; // Δήλωση λίστας RecommendedDomains τύπου FoodDomain για τα συνιστώμενα αντικείμενα

    public RecommendedAdapter(ArrayList<FoodDomain> RecommendedDomains) { // Κατασκευαστής με ορίσματα
        this.RecommendedDomains = RecommendedDomains; // Αρχικοποίηση της λίστας συνιστώμενων αντικειμένων με τα παρεχόμενα στοιχεία
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { // Υλοποίηση της μεθόδου onCreateViewHolder
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_recommended, parent, false); // Δημιουργία νέου αντικειμένου View από το αρχείο διάταξης XML

        return new ViewHolder(inflate); // Επιστροφή του νέου αντικειμένου ViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) { // Υλοποίηση της μεθόδου onBindViewHolder
        holder.title.setText(RecommendedDomains.get(position).getTitle()); // Ορισμός του κειμένου του τίτλου του αντικειμένου
        holder.fee.setText(String.valueOf(RecommendedDomains.get(position).getFee())); // Ορισμός του κειμένου της τιμής του αντικειμένου

        int drawableResourceId = holder.itemView.getContext().getResources() // Εύρεση του αναγνωριστικού πόρου της εικόνας
                .getIdentifier(RecommendedDomains.get(position).getPic(), "drawable",
                        holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext()) // Φόρτωση της εικόνας με χρήση της βιβλιοθήκης Glide
                .load(drawableResourceId) // Φόρτωση της εικόνας με το συγκεκριμένο αναγνωριστικό πόρου
                .into(holder.pic); // Εισαγωγή της εικόνας στο ImageView

        holder.addBtn.setOnClickListener(v -> { // Ορισμός ακροατή για το κουμπί προσθήκης
            Intent intent = new Intent(holder.itemView.getContext(), ShowDetailActivity.class); // Δημιουργία νέου Intent για τη μετάβαση στην ShowDetailActivity
            intent.putExtra("object", RecommendedDomains.get(position)); // Προσθήκη του επιλεγμένου αντικειμένου ως επιπλέον πληροφορία
            holder.itemView.getContext().startActivity(intent); // Έναρξη της δραστηριότητας με το Intent
        });
    }

    @Override
    public int getItemCount() { // Υλοποίηση της μεθόδου getItemCount
        return RecommendedDomains.size(); // Επιστροφή του μεγέθους της λίστας των συνιστώμενων αντικειμένων
    }

    public class ViewHolder extends RecyclerView.ViewHolder { // Δήλωση της εσωτερικής κλάσης ViewHolder
        TextView title, fee; // Δήλωση μεταβλητών title και fee τύπου TextView για τον τίτλο και την τιμή του αντικειμένου αντίστοιχα
        ImageView pic; // Δήλωση μεταβλητής pic τύπου ImageView για την εικόνα του αντικειμένου
        ImageView addBtn; // Δήλωση μεταβλητής addBtn τύπου ImageView για την εικόνα του κουμπιού προσθήκης

        public ViewHolder(@NonNull View itemView) { // Κατασκευαστής με ορίσματα
            super(itemView); // Κλήση του κατασκευαστή της υπερκλάσης
            title = itemView.findViewById(R.id.title); // Εύρεση του αναγνωριστικού για τον τίτλο
            pic = itemView.findViewById(R.id.pic); // Εύρεση του αναγνωριστικού για την εικόνα
            fee = itemView.findViewById(R.id.fee); // Εύρεση του αναγνωριστικού για την τιμή
            addBtn = itemView.findViewById(R.id.addBtn); // Εύρεση του αναγνωριστικού για το κουμπί προσθήκης
        }
    }
}