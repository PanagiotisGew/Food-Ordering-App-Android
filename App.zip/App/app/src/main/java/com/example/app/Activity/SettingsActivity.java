package com.example.app.Activity; // Πακέτο της δραστηριότητας της εφαρμογής

import android.content.Intent; // Εισαγωγή κλάσης Intent για να ξεκινήσουμε νέα δραστηριότητα
import android.os.Bundle; // Εισαγωγή κλάσης Bundle για τη διαχείριση δεδομένων
import android.view.View; // Εισαγωγή κλάσης View για τη διαχείριση γραφικών στοιχείων
import android.widget.LinearLayout; // Εισαγωγή κλάσης LinearLayout για τη διαχείριση γραμμικών διατάξεων

import androidx.appcompat.app.AppCompatActivity; // Εισαγωγή κλάσης AppCompatActivity για βασική δραστηριότητα

import com.example.app.R; // Εισαγωγή του πόρου R για την πρόσβαση στους πόρους της εφαρμογής

public class SettingsActivity extends AppCompatActivity { // Δήλωση της κλάσης SettingsActivity ως υποκλάση της AppCompatActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Υλοποίηση της μεθόδου onCreate
        super.onCreate(savedInstanceState); // Κλήση της υλοποίησης της μεθόδου onCreate της υπερκλάσης
        setContentView(R.layout.activity_settings); // Ορισμός του περιεχομένου της δραστηριότητας από το αρχείο διάταξης XML

        // Αρχικοποίηση του supportBtn και ορισμός ακροατή κλικ
        LinearLayout supportBtn = findViewById(R.id.supportBtn);
        if (supportBtn != null) {
            supportBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, SupportActivity.class));
                }
            });
        }

        // Αρχικοποίηση του profileBtn και ορισμός ακροατή κλικ για επιστροφή στην ProfileActivity
        LinearLayout profileBtn = findViewById(R.id.profileBtn);
        if (profileBtn != null) {
            profileBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, ProfileActivity.class));
                }
            });
        }

        // Αρχικοποίηση του homeBtn και ορισμός ακροατή κλικ για επιστροφή στην MainActivity
        LinearLayout homeBtn = findViewById(R.id.homeBtn);
        if (homeBtn != null) {
            homeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, MainActivity.class));
                }
            });
        }

        // Αρχικοποίηση του cartBtn και ορισμός ακροατή κλικ για μετάβαση στην CartActivity
        LinearLayout cartBtn = findViewById(R.id.cartBtn);
        if (cartBtn != null) {
            cartBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(SettingsActivity.this, CartActivity.class));
                }
            });
        }
    }
}
