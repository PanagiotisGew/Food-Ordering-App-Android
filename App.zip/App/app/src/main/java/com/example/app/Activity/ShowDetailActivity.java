package com.example.app.Activity; // Πακέτο της δραστηριότητας της εφαρμογής

import static java.util.ResourceBundle.getBundle; // Εισαγωγή στατικής μεθόδου getBundle από την κλάση ResourceBundle

import android.os.Bundle; // Εισαγωγή κλάσης Bundle για τη διαχείριση δεδομένων
import android.view.View; // Εισαγωγή κλάσης View για τη διαχείριση γραφικών στοιχείων
import android.webkit.WebView; // Εισαγωγή κλάσης WebView για την εμφάνιση περιεχομένου web
import android.widget.ImageButton; // Εισαγωγή κλάσης ImageButton για τη διαχείριση εικόνων
import android.widget.ImageView; // Εισαγωγή κλάσης ImageView για τη διαχείριση εικόνων
import android.widget.TextView; // Εισαγωγή κλάσης TextView για τη διαχείριση κειμένου

import androidx.activity.EdgeToEdge; // Εισαγωγή κλάσης EdgeToEdge για διαχείριση γενικής εμφάνισης της δραστηριότητας
import androidx.appcompat.app.AppCompatActivity; // Εισαγωγή κλάσης AppCompatActivity για βασική δραστηριότητα
import androidx.core.graphics.Insets; // Εισαγωγή κλάσης Insets για τη διαχείριση περιθωρίων
import androidx.core.view.ViewCompat; // Εισαγωγή κλάσης ViewCompat για διαχείριση προβολής
import androidx.core.view.WindowInsetsCompat; // Εισαγωγή κλάσης WindowInsetsCompat για διαχείριση περιθωρίων παραθύρου

import com.bumptech.glide.Glide; // Εισαγωγή κλάσης Glide για διαχείριση εικόνων
import com.example.app.Domain.FoodDomain; // Εισαγωγή κλάσης FoodDomain από το domain της εφαρμογής
import com.example.app.Helper.ManagementCart; // Εισαγωγή κλάσης ManagementCart για διαχείριση του καλαθιού αγορών
import com.example.app.R; // Εισαγωγή του πόρου R για την πρόσβαση στους πόρους της εφαρμογής

public class ShowDetailActivity extends AppCompatActivity { // Δήλωση της κλάσης ShowDetailActivity ως υποκλάση της AppCompatActivity
    private TextView addToCartBtn; // Δήλωση μεταβλητής addToCartBtn τύπου TextView για το κουμπί προσθήκης στο καλάθι
    private TextView titleTxt, feeTxt, descriptionTxt, numberOrderTxt, totalPriceTxt, startTxt, caloriesTxt, timeTxt; // Δήλωση μεταβλητών TextView για τα διάφορα κείμενα
    private ImageView plusBtn, minusBtn, picFood; // Δήλωση μεταβλητών ImageView για τα εικονίδια προσθήκης/αφαίρεσης και τη φωτογραφία του φαγητού
    private FoodDomain object; // Δήλωση μεταβλητής object τύπου FoodDomain για το αντικείμενο φαγητού
    private int numberOrder = 1; // Δήλωση μεταβλητής numberOrder τύπου int για την ποσότητα του φαγητού στο καλάθι
    private ManagementCart managementCart; // Δήλωση μεταβλητής managementCart τύπου ManagementCart για τη διαχείριση του καλαθιού αγορών

    @Override
    protected void onCreate(Bundle savedInstanceState) { // Υλοποίηση της μεθόδου onCreate
        super.onCreate(savedInstanceState); // Κλήση της υλοποίησης της μεθόδου onCreate της υπερκλάσης
        setContentView(R.layout.activity_show_detail); // Ορισμός του περιεχομένου της δραστηριότητας από το αρχείο διάταξης XML

        managementCart = new ManagementCart(this); // Δημιουργία νέου αντικειμένου ManagementCart
        initView(); // Κλήση της μεθόδου initView() για αρχικοποίηση των στοιχείων του UI
        getBundle(); // Κλήση της μεθόδου getBundle() για λήψη των δεδομένων από το Intent
    }

    private void getBundle() { // Ορισμός της μεθόδου getBundle() για λήψη των δεδομένων από το Intent
        object = (FoodDomain) getIntent().getSerializableExtra("object"); // Λήψη του αντικειμένου FoodDomain από το Intent

        int drawableResourceId = this.getResources().getIdentifier(object.getPic(), "drawable", this.getPackageName()); // Εύρεση του αναγνωριστικού πόρου της εικόνας
        Glide.with(this) // Εκκίνηση του Glide για φόρτωση της εικόνας
                .load(drawableResourceId) // Φόρτωση της εικόνας με το συγκεκριμένο αναγνωριστικό πόρου
                .into(picFood); // Εισαγωγή της εικόνας στο ImageView

        // Ορισμός των κειμένων του UI με βάση τα δεδομένα του αντικειμένου FoodDomain
        titleTxt.setText(object.getTitle());
        feeTxt.setText("S" + object.getFee());
        descriptionTxt.setText(object.getDescription());
        numberOrderTxt.setText(String.valueOf(numberOrder));
        caloriesTxt.setText(object.getCalories() + " Calories");
        startTxt.setText(object.getStar() + "");
        timeTxt.setText(object.getTime() + " Minutes");
        totalPriceTxt.setText("$" + Math.round(numberOrder * object.getFee()));

        // Ορισμός ακροατή κλικ για το κουμπί προσθήκης
        plusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberOrder = numberOrder + 1;
                numberOrderTxt.setText(String.valueOf(numberOrder));
                totalPriceTxt.setText("$" + Math.round(numberOrder * object.getFee()));
            }
        });

        // Ορισμός ακροατή κλικ για το κουμπί αφαίρεσης
        minusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (numberOrder > 1) {
                    numberOrder = numberOrder - 1;
                }
                numberOrderTxt.setText(String.valueOf(numberOrder));
                totalPriceTxt.setText("$" + Math.round(numberOrder * object.getFee()));
            }
        });

        // Ορισμός ακροατή κλικ για το κουμπί προσθήκης στο καλάθι
        addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                object.setNumberInCart(numberOrder); // Ορισμός της ποσότητας στο καλάθι για το συγκεκριμένο αντικείμενο
                managementCart.insertFood(object); // Εισαγωγή του αντικειμένου στο καλάθι
            }
        });
    }

    private void initView() { // Ορισμός της μεθόδου initView() για αρχικοποίηση των στοιχείων του UI
        addToCartBtn = findViewById(R.id.addToCartBtn);
        titleTxt = findViewById(R.id.titleTxt);
        feeTxt = findViewById(R.id.priceTxt);
        descriptionTxt = findViewById(R.id.descriptionTxt);
        numberOrderTxt = findViewById(R.id.numberItemTxt);
        plusBtn = findViewById(R.id.plusCardBtn);
        minusBtn = findViewById(R.id.minusCardBtn);
        picFood = findViewById(R.id.foodPic);
        totalPriceTxt = findViewById(R.id.totalPriceTxt);
        startTxt = findViewById(R.id.starTxt);
        caloriesTxt = findViewById(R.id.caloriesTxt);
        timeTxt = findViewById(R.id.timeTxt);
    }
}

