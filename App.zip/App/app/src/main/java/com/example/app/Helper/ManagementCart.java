package com.example.app.Helper; // Πακέτο της κλάσης βοηθητικών

import android.content.Context; // Εισαγωγή του Context για την επικοινωνία με το περιβάλλον της εφαρμογής
import android.widget.Toast; // Εισαγωγή του Toast για την εμφάνιση μηνυμάτων στην οθόνη του χρήστη

import com.example.app.Domain.FoodDomain; // Εισαγωγή της κλάσης FoodDomain από το πεδίο της εφαρμογής
import com.example.app.Interface.ChangeNumberItemsListener; // Εισαγωγή της διεπαφής ChangeNumberItemsListener από το πεδίο της εφαρμογής

import java.util.ArrayList; // Εισαγωγή της ArrayList για τη διαχείριση λιστών αντικειμένων

public class ManagementCart { // Δήλωση της κλάσης ManagementCart
    private final Context context; // Ιδιωτική μεταβλητή για το περιβάλλον της εφαρμογής
    private final TinyDB tinyDB; // Ιδιωτική μεταβλητή για την αποθήκευση δεδομένων

    public ManagementCart(Context context) { // Δημιουργός με παράμετρο
        this.context = context; // Αρχικοποίηση του περιβάλλοντος
        this.tinyDB = new TinyDB(context); // Δημιουργία νέου αντικειμένου TinyDB με το περιβάλλον
    }

    public void insertFood(FoodDomain item) { // Μέθοδος για την εισαγωγή φαγητού στο καλάθι
        ArrayList<FoodDomain> listFood = getListCart(); // Λήψη της λίστας του καλαθιού
        boolean existAlready = false; // Έλεγχος για ύπαρξη του φαγητού
        int n = 0; // Μεταβλητή για τον έλεγχο του αριθμού του φαγητού
        for (int i = 0; i < listFood.size(); i++) { // Διάσχιση της λίστας του καλαθιού
            if (listFood.get(i).getTitle().equals(item.getTitle())) { // Έλεγχος για ύπαρξη του φαγητού
                existAlready = true; // Ημίτονο για τον έλεγχο της ύπαρξης
                n = 1; // Ορισμός του μετρητή
                break; // Διακοπή της επανάληψης
            }
        }
        if (existAlready) { // Έλεγχος για ύπαρξη του φαγητού
            listFood.get(n).setNumberInCart(item.getNumberInCart()); // Ορισμός του αριθμού του φαγητού
        } else { // Αν δεν υπάρχει το φαγητό
            listFood.add(item); // Προσθήκη του φαγητού
        }

        tinyDB.putListObject("CardList", listFood); // Αποθήκευση της λίστας του καλαθιού
        Toast.makeText(context, "Added to your cart", Toast.LENGTH_SHORT).show(); // Εμφάνιση μηνύματος στον χρήστη
    }

    public ArrayList<FoodDomain> getListCart() { // Μέθοδος για την ανάκτηση της λίστας του καλαθιού
        return tinyDB.getListObject("CardList"); // Επιστροφή της λίστας του καλαθιού
    }

    public void minusNumberFood(ArrayList<FoodDomain> listfood, int position, ChangeNumberItemsListener changeNumberItemsListener) { // Μέθοδος για τη μείωση της ποσότητας του φαγητού
        if (listfood.get(position).getNumberInCart() == 1) { // Έλεγχος για την ποσότητα του φαγητού
            listfood.remove(position); // Αφαίρεση του φαγητού από τη λίστα
        } else { // Αν η ποσότητα δεν είναι 1
            listfood.get(position).setNumberInCart(listfood.get(position).getNumberInCart() - 1); // Μείωση της ποσότητα
        }
        tinyDB.putListObject("CardList", listfood); // Αποθήκευση της ανανεωμένης λίστας του καλαθιού
        changeNumberItemsListener.changed(); // Κλήση της μεθόδου changed() για ενημέρωση του ακροατή
    }
    public void plusNumberFood(ArrayList<FoodDomain> listfood, int position, ChangeNumberItemsListener changeNumberItemsListener) { // Μέθοδος για την αύξηση της ποσότητας του φαγητού
        listfood.get(position).setNumberInCart(listfood.get(position).getNumberInCart() + 1); // Αύξηση της ποσότητας του φαγητού κατά ένα
        tinyDB.putListObject("CardList", listfood); // Αποθήκευση της ανανεωμένης λίστας του καλαθιού
        changeNumberItemsListener.changed(); // Κλήση της μεθόδου changed() για ενημέρωση του ακροατή
    }

    public Double getTotalFee() { // Μέθοδος για τον υπολογισμό του συνολικού κόστους
        ArrayList<FoodDomain> listfood2 = getListCart(); // Λήψη της λίστας του καλαθιού
        double fee = 0; // Αρχικοποίηση του συνολικού κόστους
        for (int i = 0; i < listfood2.size(); i++) { // Διάσχιση της λίστας του καλαθιού
            fee = fee + (listfood2.get(i).getFee() * listfood2.get(i).getNumberInCart()); // Υπολογισμός του συνολικού κόστους
        }
        return fee; // Επιστροφή του συνολικού κόστους
    }

    public void clearCart() { // Μέθοδος για τον καθαρισμό του καλαθιού
        tinyDB.remove("CardList"); // Αφαίρεση της λίστας του καλαθιού από την αποθήκευση
    }

}